package com.epam.tam.steps;

import java.util.concurrent.TimeUnit;

import junit.framework.Assert;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import com.epam.tam.Waiter;
import com.epam.tam.WebDriverSingleton;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefination {
	private static WebDriver driver =WebDriverSingleton.getWebDriverInstance();
	private static final String HOME_PAGE="//button[@id='gh-shop-a' and text()='Shop by category']";
	private static final String HOME_PAGE_TEXT="Shop by category";
	private static final String FASHION_LINK="Fashion";
	private static final String FASHION_PAGE="//span[@class='b-pageheader__text' and text()='Fashion']";
	private static final String FASHION_PAGE_TEXT="Fashion";
	private static final String SHOES_Button="//span[@class='b-accordion-text' and text()='Shoes']/..";
	private static final String MENS_SHOE_LINK="Men's Shoes";
	private static final String WOMENS_SHOE_LINK="Women's Shoes";
	private static final String MENS_SHOE_PAGE="//span[@class='b-pageheader__text' and contains(text(),'Shoes')]";
	private static final String WOMENS_SHOE_PAGE="//span[@class='b-pageheader__text' and contains(text(),'Shoes')]";
	private static final String MENS_CASUALSHOE_LINK="Men's Casual Shoes";
	private static final String WOMENS_BOOTS_LINK="Women's Boots";
	private static final String MENS_SHOE_PAGE_TEXT="Men's Shoes";
	private static final String WOMENS_SHOE_PAGE_TEXT="Women's Shoes";
	private static final String MENS_CASUALSHOE_PAGE="//span[@class='b-pageheader__text' and contains(text(),'Casual Shoes')]";
	private static final String WOMENS_BOOTS_PAGE="//span[@class='b-pageheader__text' and contains(text(),'Boots')]";
	private static final String MENS_CASUALSHOE_PAGE_TEXT="Men's Casual Shoes";
	private static final String WOMENS_BOOTS_PAGE_TEXT="Women's Boots";
	private static final String FIRST_SHOE_NAME="//li[contains(@id,'items[0]')]//div//h3";
	private static String FIRST_SHOE_NAME_TEXT=null;
	private static final String ITEM_TITLE="//h1[@id='itemTitle']";
	private static final String SHOE_SIZE="//select[@id='msku-sel-2']";
	private static final String SHOE_COLOUR="//select[@id='msku-sel-1']";
	private static final String SHOE_SIZE_SELECT="//select[@id='msku-sel-2']//option[not(contains(@disabled,'disabled'))][2]";
	private static final String SHOE_COLOUR_SELECT="//select[@id='msku-sel-1']//option[not(contains(@disabled,'disabled'))][2]";
	private static final String ADDTOCART_BUTTON="//a[@id='isCartBtn_btn']";
	private static final String ADDTOCART_PAGE="//h1[@class='mb15 nowrap']";
	private static final String ADDTOCART_MESSAGE="//div[@class='msgWrapper']//span";
	private static final String ADDTOCART_PAGE_TEXT="Your eBay Shopping Cart";
	
	@Given("^Open ebay website$")
	public void open_ebay_website() throws Throwable {
		driver.get("https://www.ebay.com/");
		System.out.println("Opened ebay site");
	}

	@SuppressWarnings("deprecation")
	@Then("^Verify ebay home page$")
	public void verify_ebay_home_page() throws Throwable {
		By homePage= By.xpath(HOME_PAGE);
		String homePageText=driver.findElement(homePage).getText();
		Assert.assertEquals("ebay website successfully not loaded", HOME_PAGE_TEXT, homePageText);
	}

	@When("^User selectes Fashin link$")
	public void user_selectes_Fashin_link() throws Throwable {
		By fashionLink= By.linkText(FASHION_LINK);
		driver.findElement(fashionLink).click();
		System.out.println("Selected Fashion link");
	}

	@Then("^Verify Fashion Page open successfully$")
	public void verify_Fashion_Page_open_successfully() throws Throwable {
		By fashionpage= By.xpath(FASHION_PAGE);
		String fashionPageText=driver.findElement(fashionpage).getText();
		Assert.assertEquals("Fashion page not opened successfully", FASHION_PAGE_TEXT, fashionPageText);
	}

	@When("^User selects shoes link$")
	public void user_selects_shoes_link() throws Throwable {
		By shoesButton= By.xpath(SHOES_Button);
		driver.findElement(shoesButton).click();
		System.out.println("Clicked on shoes Button");
	}

	@When("^Select Mens shoes from list$")
	public void select_Mens_shoes_from_list() throws Throwable {
		By mensshoesLink= By.linkText(MENS_SHOE_LINK);
		driver.findElement(mensshoesLink).click();
		System.out.println("Clicked Men's shoes link");
	}

	@Then("^Verify Mens shoes page open successfully$")
	public void verify_Mens_shoes_page_open_successfully() throws Throwable {
		By mensShoespage= By.xpath(MENS_SHOE_PAGE);
		String mensShoesPageText=driver.findElement(mensShoespage).getText();
		Assert.assertEquals("Mens shoes page not opened successfully", MENS_SHOE_PAGE_TEXT, mensShoesPageText);
	}

	@When("^User select Mens casual shoes$")
	public void user_select_Mens_casual_shoes() throws Throwable {
		By mensCasualShoesLink= By.linkText(MENS_CASUALSHOE_LINK);
		driver.findElement(mensCasualShoesLink).click();
		System.out.println("Clicked on Men's Casual shoes link");
	}

	@Then("^Mens casual shoes page will open successfully$")
	public void mens_casual_shoes_page_will_open_successfully() throws Throwable {
		By mensCasualShoespage= By.xpath(MENS_CASUALSHOE_PAGE);
		String mensCasualShoesPageText=driver.findElement(mensCasualShoespage).getText();
		Assert.assertEquals("Mens shoes page not opened successfully", MENS_CASUALSHOE_PAGE_TEXT, mensCasualShoesPageText);
		Thread.sleep(3000);
	}

	@When("^User select shoe from given list$")
	public void user_select_shoe_from_given_list() throws Throwable {
		By firstShoe= By.xpath(FIRST_SHOE_NAME);
		Waiter.waitForElementClickable(driver, 20, firstShoe);
		FIRST_SHOE_NAME_TEXT=driver.findElement(firstShoe).getText();
		driver.findElement(firstShoe).click();
		System.out.println("Selected first shoe in list");
	}

	@Then("^Shoe details will display$")
	public void shoe_details_will_display() throws Throwable {
		By itemTitle=By.xpath(ITEM_TITLE);
		Assert.assertEquals("Selected shoe not opened successfully", FIRST_SHOE_NAME_TEXT, driver.findElement(itemTitle).getText());

	}

	@When("^User select shoe size$")
	public void user_select_shoe_size() throws Throwable {
		try{
		    By shoeColour=By.xpath(SHOE_COLOUR_SELECT);
		    if(driver.findElement(shoeColour) != null){
		    	driver.findElement(shoeColour).click();
		    }
		}
		catch(Exception e){
			System.out.println("Field is not available");
		}
		try{
			By shoeSize=By.xpath(SHOE_SIZE);
		    if(driver.findElement(shoeSize) != null){
		    Select sizeSelect = new Select(driver.findElement(shoeSize));
		    sizeSelect.selectByVisibleText("6M");
			Thread.sleep(3000);
		    }
		}
		catch(Exception e){
			System.out.println("Field is not available");
		}	    
		System.out.println("Selected size and colour");
	}

	@When("^User add the shoe to Add to cart$")
	public void user_add_the_shoe_to_Add_to_cart() throws Throwable {
	    By addToCart=By.xpath(ADDTOCART_BUTTON);
	    driver.findElement(addToCart).click();
	    System.out.println("Item added to cart");
	}

	@Then("^shoe will add successfully to cart$")
	public void shoe_will_add_successfully_to_cart() throws Throwable {
		By addToCartPage=By.xpath(ADDTOCART_PAGE);
		By addToCartMessage=By.xpath(ADDTOCART_MESSAGE);
		Assert.assertEquals("Add to Cart Page not opened successfully", ADDTOCART_PAGE_TEXT, driver.findElement(addToCartPage).getText());
	}
	
	@When("^Select \"([^\"]*)\" from list$")
	public void select_from_list(final String category) throws Throwable {
		System.out.println(category);
		if(category.equalsIgnoreCase("MenShoes")){
		By mensshoesLink= By.linkText(MENS_SHOE_LINK);
		driver.findElement(mensshoesLink).click();
		System.out.println("Clicked on Men's shoe link");
		}
		else if(category.equalsIgnoreCase("WomenShoes")){
			By WomensshoesLink= By.linkText(WOMENS_SHOE_LINK);
			driver.findElement(WomensshoesLink).click();
			System.out.println("Clicked on Women's shoe link");
			}
	}

	@Then("^Verify selected \"([^\"]*)\" page open successfully$")
	public void verify_selected_page_open_successfully(String arg1) throws Throwable {
		if(arg1.equalsIgnoreCase("MenShoes")){
			By mensShoespage= By.xpath(MENS_SHOE_PAGE);
			String mensShoesPageText=driver.findElement(mensShoespage).getText();
			Assert.assertEquals("Mens shoes page not opened successfully", MENS_SHOE_PAGE_TEXT, mensShoesPageText);
		}
		else if(arg1.equalsIgnoreCase("WomenShoes")){
			By womensShoespage= By.xpath(WOMENS_SHOE_PAGE);
			String mensShoesPageText=driver.findElement(womensShoespage).getText();
			Assert.assertEquals("Mens shoes page not opened successfully", WOMENS_SHOE_PAGE_TEXT, mensShoesPageText);
		}
	}

	@When("^User select \"([^\"]*)\"$")
	public void user_select(String arg1) throws Throwable {
		if(arg1.equalsIgnoreCase("MensCasualShoe")){
			By mensCasualShoesLink= By.linkText(MENS_CASUALSHOE_LINK);
			driver.findElement(mensCasualShoesLink).click();
			System.out.println("Clicked on Men's Casual shoe link");
		}
		else if(arg1.equalsIgnoreCase("WomensBootShoe")){
			By womensBootsLink= By.linkText(WOMENS_BOOTS_LINK);
			driver.findElement(womensBootsLink).click();
			System.out.println("Clicked on Women's Boot link");
		}
	}
	
	@Then("^Selected \"([^\"]*)\" page will open successfully$")
	public void selected_page_will_open_successfully(String arg1) throws Throwable {
		if(arg1.equalsIgnoreCase("MensCasualShoe")){
			By mensCasualShoespage= By.xpath(MENS_CASUALSHOE_PAGE);
			String mensCasualShoesPageText=driver.findElement(mensCasualShoespage).getText();
			Assert.assertEquals("Mens shoes page not opened successfully", MENS_CASUALSHOE_PAGE_TEXT, mensCasualShoesPageText);
		}
		else if(arg1.equalsIgnoreCase("WomensBootShoe")){
			By womensBootpage= By.xpath(WOMENS_BOOTS_PAGE);
			String womensBootsPageText=driver.findElement(womensBootpage).getText();
			Assert.assertEquals("Womens Boot's page not opened successfully", WOMENS_BOOTS_PAGE_TEXT, womensBootsPageText);
		}
	}

}
