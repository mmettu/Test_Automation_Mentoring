package com.epam.tam;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Waiter {

	public static void waitForElementClickable(WebDriver driver,int timeOut, final By by){
		new WebDriverWait(driver,timeOut).pollingEvery(2, TimeUnit.SECONDS).until(ExpectedConditions.elementToBeClickable(by));
	}
}
