package com.epam.tam;

import static org.junit.Assert.*;

import java.util.concurrent.TimeUnit;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features = ("src/test/resource/feature"), glue = {
				"com/epam/tam/steps"}, tags = { "@Scenario"}
//@CC_EMTest,@CC_BLTest,@CC_Encompass,@CC_test

)

public class RunnerTest {
	@BeforeClass
	public static void setup(){
		WebDriverSingleton.getWebDriverInstance().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		WebDriverSingleton.getWebDriverInstance().manage().window().maximize();
	}
	@AfterClass
	public static void closeBrowser(){
		WebDriverSingleton.getWebDriverInstance().close();
	}

}
