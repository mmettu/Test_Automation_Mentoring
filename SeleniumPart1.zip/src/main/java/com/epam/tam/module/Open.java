package com.epam.tam.module;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Open {
	public static void main(String args[]) throws InterruptedException{
		WebDriver driver;

		System.setProperty("webdriver.chrome.driver", "C:/Users/Mmettu/Desktop/Automation/Praveen_prjct/CC_new/CC/src/test/resources/drivers/chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://wizzair.com/");
		
		Thread.sleep(10000);
		
		driver.quit();

		}
}
