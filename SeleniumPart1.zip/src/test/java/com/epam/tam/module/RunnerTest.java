package com.epam.tam.module;

import java.util.Set;
import java.util.concurrent.TimeUnit;

import junit.framework.Assert;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.epam.tam.module.utils.Waiter;

public class RunnerTest {
	public static WebDriver driver;
		
	@BeforeTest
	public static void setup(){
	System.setProperty("webdriver.chrome.driver", "src/test/resources/chromedriver.exe");
	driver = new ChromeDriver();
	System.out.println("Initialized the driver");
	}
	
	@AfterTest
	public static void tearDown() {
		System.out.println("Closing the driver");
		driver.quit();
	}
	@Test
	public void Open(){

		driver.get("https://wizzair.com/");
		System.out.println("In Open");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		String HomePageText=driver.findElement(By.xpath("//div/h2[contains(text(),'Explore your travel')]")).getText();
		System.out.println(HomePageText);
		Assert.assertEquals("HomePage not opened Successfully","Explore your travel opportunities with WIZZ!", HomePageText);
	}
	@Test
	public void originField(){
		WebElement origin = driver.findElement(By.xpath("//input[@id='search-departure-station']"));
		origin.click();
		origin.sendKeys("Belgium");
		WebElement originAirport = driver.findElement(By.xpath("//*[(@class='locations-container__location__name') and (contains(.,' Brussels Charleroi '))]"));
		originAirport.click();
		Waiter.waitForElementPresent(driver, 6, "//div[@class='rf-input__location rf-input__location--hint' and text()='Brussels Charleroi']");
		String originValue= driver.findElement(By.xpath("//div[@class='rf-input__location rf-input__location--hint' and text()='Brussels Charleroi']")).getText();
		System.out.println(originValue);
		Assert.assertEquals("Aiport selected is different","Brussels Charleroi CRL", originValue);
		
	}
	@Test (priority=1)
	public void destinationField(){
		WebElement destination = driver.findElement(By.xpath("//input[@id='search-arrival-station']"));
		destination.click();
		destination.sendKeys("Germany");
		Waiter.waitForElementPresent(driver, 6, "//div[@class='locations-container__no-results']/span");
		String destinationResult = driver.findElement(By.xpath("//div[@class='locations-container__no-results']/span")).getText();
		System.out.println(destinationResult);
		Assert.assertEquals("Returned results for Germanyt","There is no result for this search.! :(", destinationResult);
		destination.click();
		destination.sendKeys("Hungary");
		WebElement destinationAirport = driver.findElement(By.xpath("//*[(@class='locations-container__location__name') and (contains(.,' Budapest '))]"));
		destinationAirport.click();
		Waiter.waitForElementPresent(driver, 6, "//div[@class='rf-input__location rf-input__location--hint' and text()='Budapest']");
		String destinationValue= driver.findElement(By.xpath("//div[@class='rf-input__location rf-input__location--hint' and text()='Budapest']")).getText();
		System.out.println(destinationValue);
		Assert.assertEquals("Aiport selected is different","Budapest BUD", destinationValue);		
	}	
	@Test (priority=2)
	public void selectDepartureDate() throws InterruptedException{
		driver.findElement(By.xpath("//div[@id='search-departure-date']")).click();
		Waiter.waitForElementClickable(driver, 6, "//div[@class='pika-lendar'][1]//td[@class='is-today']/following-sibling::td[2]");
		driver.findElement(By.xpath("//div[@class='pika-lendar'][1]//td[@class='is-today']/following-sibling::td[2]")).click();
		driver.findElement(By.xpath("//div[@class='calendar__button']/button[text()='OK']")).click();
		Thread.sleep(2000);
	}
	@Test (priority=3)
	public void selectReturnDate() throws InterruptedException{
		driver.findElement(By.xpath("//div[@id='search-return-date']")).click();
		try{
			Waiter.waitForElementClickable(driver, 4, "//div[@class='pika-lendar'][1]//td[@class='is-selected']/following-sibling::td[2]");
			driver.findElement(By.xpath("//div[@class='pika-lendar'][1]//td[@class='is-selected']/following-sibling::td[2]")).click();
		}
		catch (Exception e){
			driver.findElement(By.xpath("//div[@class='pika-lendar'][1]//td[@class='is-selected']/../following-sibling::tr[1]/td[1]/button")).click();
		}
		driver.findElement(By.xpath("//div[@class='calendar__button']/button[text()='OK']")).click();
		Thread.sleep(2000);
	}
	@Test (priority=4)
	public void selectPassengers() throws InterruptedException{
		driver.findElement(By.xpath("//div[@id='search-passenger']")).click();
		Waiter.waitForElementClickable(driver, 6, "//div[@class='stepper stepper--flight-search'][2]/button[@class='stepper__button stepper__button--add']");
		driver.findElement(By.xpath("//div[@class='stepper stepper--flight-search'][2]/button[@class='stepper__button stepper__button--add']")).click();
		driver.findElement(By.xpath("//div[@class='flight-search__panel__done-btn gutter-bottom']/button[@class='rf-button rf-button--medium rf-button--primary']")).click();
		String passengerCount;
		passengerCount=driver.findElement(By.xpath("//div[@class='rf-input__input passenger-counter-input__input']")).getText();
		System.out.println(passengerCount);
	}
	@Test (priority=5)
	public void verifyPassengers(){
		String passengerCount;
		passengerCount=driver.findElement(By.xpath("//div[@class='rf-input__input passenger-counter-input__input']")).getText();
		System.out.println(passengerCount);
		Assert.assertEquals("Selected passengers count is wrong","1 adult 1 child", passengerCount);		
	}
	@Test (priority=6)
	public void performSearch() {
		String searchPageHeading;
		driver.findElement(By.xpath("//div/button[@class='rf-button rf-button--medium rf-button--primary flight-search__panel__cta-btn']")).click();
		String currentHandle = driver.getWindowHandle();
//		Set<String> handles = driver.getWindowHandles() ;
		for(String winHandle : driver.getWindowHandles()){
            if(currentHandle.equalsIgnoreCase(winHandle))
               continue; 
            driver.switchTo().window(winHandle);
        }  
		Waiter.waitForElement(2000);
		Waiter.waitForElementPresent(driver, 6, "//h2[@class='booking-flow__step__title heading heading--1' and text()='Select flights']");
		searchPageHeading=driver.findElement(By.xpath("//h2[@class='booking-flow__step__title heading heading--1' and text()='Select flights']")).getText();
		Assert.assertEquals("Not routed to Search page","SELECT FLIGHTS", searchPageHeading);
	}
}
