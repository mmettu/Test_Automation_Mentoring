package com.epam.tam.module.utils;

public class Waiter {

	public static void waitForElement(long time){
		try {
			Thread.sleep(time);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
